CREVIA AI — CANVA / QTTN ASSET PACKAGE
Source: User-uploaded QTTN.pdf (44 pages)
Exported: 44 rendered page-compositions as optimized JPEGs.
Each filename contains a descriptive group and original PDF page number.
See asset-catalog.csv for category, description, dimensions, and suggested usage.

Categories:
- accessories: vintage leather handbag and Hapas denim bag (pages 1-3, 40-44)
- beauty: Cocoon, Dior, Medicube, L'Oreal (pages 4-6, 28-30, 34-39)
- home: DeMee baby bedding and pillows (pages 7-9)
- food: noodles, cookies, biscotti, lotus gift box, Kido's mooncakes (pages 10-12, 16-18, 25-27)
- beverage: salted coffee, The Legend coffee, brewing lifestyle (pages 13-15, 19-24)
- fashion: black high heels (pages 31-33)

IMPORTANT:
These are exports of the 44 PDF pages as complete compositions. Some pages include advertising text or product overlays as present in the source PDF. The images were not AI-regenerated or retouched. For best source fidelity, use the page JPEGs as supplied.
